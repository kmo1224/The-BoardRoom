# Classic Boardroom

A responsive, self-contained classic board-game website. Includes two-player Chess, Checkers, Connect Four, Tic-Tac-Toe, and Reversi.

## Publish with GitHub Pages
1. Create a repository named `YOUR-USERNAME.github.io` (or use an existing repository).
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. After deployment, visit `https://YOUR-USERNAME.github.io`.

No build step, frameworks, external libraries, sign-in, or server required.
